from pydantic import BaseModel, EmailStr, Field, validator
from fastapi import HTTPException
from typing import Optional
from app.utiles.logger import get_logger
import re

logger = get_logger(__name__)

class RegisterRequest(BaseModel):
    first_name : str
    last_name : str
    username : str
    email : EmailStr
    phone_number : int
    password : str
    dob : str
    doj : str
    address : str
    
    # Validator to ensure only Gmail addresses are allowed
    @validator('email')
    def validate_gmail(cls, v):
        if not v.endswith("@gmail.com"):
            logger.warning("Invalid email domain attempted: %s", v)
            raise HTTPException(status_code = 400,
                                detail = "Invalid Email")
        return v
    
    # Validator to enforce strong password policy
    @validator('password')
    def validate_password(cls,v):
        if not re.match(r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!#%*?&]{8,20}$', v):
            logger.warning("Password Requirement does not match")
            raise HTTPException(status_code =400,
                                detail = "Password must be 8-20 chars, include uppercase, lowercase, number, special char")
        return v
    
class RegisterResponse(BaseModel):
    message : str
    username : str
    email : str

class LoginRequest(BaseModel):
    username_or_email : str
    password : str

class LoginResponse(BaseModel):
    message : str
    username : str
    token : str

class UpdateDetailsRequest(BaseModel):
    password: str
    username: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    email: Optional[EmailStr] = None
    phone_number: Optional[int] = None
    dob: Optional[str] = None
    address: Optional[str] = None
 
class UpdateDetailsResponse(BaseModel):
    message: str
    username: str

class ChangePassword(BaseModel):
    email : str
    old_password : str
    new_password : str

class ChangePasswordotp(BaseModel):
    username:str
    otp:str


class ForgotPasswordRequest(BaseModel):
    username_or_email: str
 
class VerifyOtpRequest(BaseModel):
    username_or_email: str
    otp: str
    new_password: str
 

 
